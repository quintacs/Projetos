/**
 * 
 */
package br.com.qi.form;

import java.util.Hashtable;
import java.util.List;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * @author cesar
 *
 */
public class PrincipalForm implements Form {
	
	
	@Override
	public String getNomeForm() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDescricaoForm() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Form parse(ServletRequest req, ServletResponse resp) {
		// TODO Auto-generated method stub
		return null;
	}

}
